package aula;

public class TestaBanco {

	public static void main(String[] args) {
		
		Banco bItau = new Banco();
		
		Conta cMaria = new Conta(123, "Maria", 500);
		Conta cMaria2 = new Conta(123, "Maria", 500);
		Conta cRenan = new Conta(456, "Maria", 500);
		
		bItau.addConta(cMaria);
		bItau.addConta(cMaria2);
		bItau.addConta(cRenan);
		
		System.out.println(bItau);
		
	}
	
}
