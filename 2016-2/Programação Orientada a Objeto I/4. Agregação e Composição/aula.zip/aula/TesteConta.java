package aula;

public class TesteConta {

	public static void main(String[] args) {
		
		Conta cMaria = new Conta(123, "Maria", 500);		
		Conta cMaria2 = new Conta(123, "Maria", 500);
		
		Conta cMaria3 = null;
		
		System.out.println(cMaria);
		System.out.println(cMaria2);
		
		
		System.out.print("Operador de igualdade - Referência: ");
		if (cMaria == cMaria2) {
			System.out.println("Igual");
		} else {
			System.out.println("Não é Igual!");
		}
		

		System.out.print("Método Equals - Considerando o "
				+ "estado do objeto: ");
		
		if (cMaria.equals(cMaria2)) {
			System.out.println("Igual");
		} else {
			System.out.println("Não é Igual!");
		}	
		
		
	}
	
}
