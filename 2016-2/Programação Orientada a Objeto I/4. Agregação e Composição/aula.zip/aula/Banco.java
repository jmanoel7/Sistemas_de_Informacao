package aula;

import java.util.ArrayList;
import java.util.List;

public class Banco {
	
	private List<Conta> listaConta = new ArrayList<Conta>();
	
	public boolean addConta(Conta conta) {
		boolean sucesso = false;		
		
		if ( !listaConta.contains(conta) ) {
			listaConta.add(conta);
			sucesso = true;
		} 
		return sucesso;
	}

	@Override
	public String toString() {
		return "Banco [listaConta=" + listaConta + "]";
	}	

}
