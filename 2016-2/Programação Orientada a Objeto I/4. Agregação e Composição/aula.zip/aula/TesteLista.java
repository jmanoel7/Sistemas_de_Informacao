package aula;

import java.util.ArrayList;
import java.util.List;

public class TesteLista {	
	
	public static void main(String[] args) {
		
		List<Conta> listaContas = new ArrayList<Conta>();
		
		listaContas.add(new Conta(123, "Renan", 100));
		listaContas.add(new Conta(567, "Maria", 350));
		listaContas.add(new Conta(599, "Pedro", 200));
		
		for (Conta conta : listaContas) {
			System.out.println(conta);
		}
		
	}
	
}
