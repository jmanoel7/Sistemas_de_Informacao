package aula;

public class Conta {

	private int numero;
	private String titular;
	private float saldo;
		
	public Conta(int numero, String titular) {		
		this.numero = numero;
		this.titular = titular;
	}
	
	public Conta(int numero, String titular, float saldo) {		
		this.numero = numero;
		this.titular = titular;
		this.saldo = saldo;
	}

	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public float getSaldo() {
		return saldo;
	}
	
	public boolean depositar (float valor) {
		boolean sucesso = false;
		
		if (valor > 0) {
			saldo += valor;
			sucesso = true;	
		}
		
		return sucesso;
	}
	
	public boolean sacar(float valor) {
		boolean sucesso = false;
		
		if (saldo >= valor) {
			saldo -= valor;
			sucesso = true;
		}
		
		return sucesso;		
	}

	@Override
	public String toString() {
		return "Conta [numero=" + numero + 
				", titular=" + titular + ", saldo="
				+ saldo + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Conta other = (Conta) obj;
		if (numero != other.numero)
			return false;
		if (titular == null) {
			if (other.titular != null)
				return false;
		} else if (!titular.equals(other.titular))
			return false;
		return true;
	}

	

	
	
	
	
	
	
}
