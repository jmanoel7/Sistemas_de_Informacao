package aula;

public class TesteConta2 {

	public static void main(String[] args) {
		
		Conta cMaria = new Conta(123, "Maria", 500);		
		System.out.println(cMaria);		
		
	}
	
}
