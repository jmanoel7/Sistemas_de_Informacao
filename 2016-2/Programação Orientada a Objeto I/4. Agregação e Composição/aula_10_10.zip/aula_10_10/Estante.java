package aula_10_10;

import java.util.ArrayList;
import java.util.List;

public class Estante {

	private String numero;	
	private List<Livro> listaLivro = new ArrayList<Livro>();
	
	public String getNumero() {
		return numero;
	}

	public Estante(String numero) {		
		this.numero = numero;
	}

	
	
	@Override
	public String toString() {
		return "Estante [numero=" + numero + ", listaLivro=" + listaLivro + "]";
	}
	
	public boolean removeLivro(Livro livro) {
		boolean sucesso = false;
		
		if ( (livro != null) && 
			 (listaLivro.remove(livro)) ) {
			sucesso = true;
		}
		
		return sucesso;
	}

	public boolean addLivro(Livro livro) {
		boolean sucesso = false;		
		if ( (livro != null) && 
			 (listaLivro.size() < 3) &&
			 (!listaLivro.contains(livro))
				
			) {
			listaLivro.add(livro);
			sucesso = true;
		}		
		return sucesso;				
	}
	
	
	
}
