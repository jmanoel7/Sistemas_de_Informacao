package aula_10_10;

public class TesteEstante {

	public static void main(String[] args) {
		
		Estante estante1 = new Estante("B12");
		
		Livro livro0 = new Livro("Java", "Deitel", 
				"Editora Globo");
		
		Livro livro1 = new Livro("Java", "Deitel", 
				"Editora Globo");
		
		Livro livro2 = new Livro("PHP", "Fulano", 
				"Editora Ciclano");
		
		Livro livro3 = new Livro("Python", "Fulano", 
				"Editora Ciclano");
		
		Livro livro4 = new Livro("Delphi", "Fulano", 
				"Editora Ciclano");
		
		System.out.println(estante1);		
			
		estante1.addLivro(livro0);
		estante1.addLivro(livro1);
		estante1.addLivro(livro2);
		estante1.addLivro(livro3);
		estante1.addLivro(livro4);
		System.out.println(estante1);
		
		estante1.removeLivro(livro2);
		System.out.println(estante1);	
		
		
	}
	
}
