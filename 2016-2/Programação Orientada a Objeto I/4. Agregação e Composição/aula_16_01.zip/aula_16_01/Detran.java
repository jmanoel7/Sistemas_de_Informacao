package aula_16_01;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

public class Detran {

	private String cidade;
	private List<Carro> listaCarros = new ArrayList<Carro>();

	public Detran(String cidade) {		
		this.cidade = cidade;
	}	
	
	public void removeCarro(Carro carro) {
		
		if (listaCarros.contains(carro)) {
			listaCarros.remove(carro);
		} else {
			throw new IndexOutOfBoundsException("O carro "
					+ "não está na lista");
		}
		
	}
	
	public void addCarro(Carro carro) {
		
		if (carro == null) {
			throw new NullPointerException("O carro "
					+ "não pode ser nulo."); 
		}
		
		if (listaCarros.contains(carro)) {
			throw new InvalidParameterException("O carro "
					+ "já está cadastrado.");
		}
		
		listaCarros.add(carro);
		
	}
	
	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	@Override
	public String toString() {
		return "Detran [cidade=" + cidade + ", listaCarros=" + listaCarros
				+ "]";
	}

	
	
	
}
