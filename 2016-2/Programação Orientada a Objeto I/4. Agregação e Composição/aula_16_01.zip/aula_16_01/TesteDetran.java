package aula_16_01;

public class TesteDetran {

	public static void main(String[] args) {
				
		Proprietario p = new Proprietario("888", "Renan");
		//System.out.println(p);
						
		Carro c = new Carro("Civic", "NNN-8888", 987, p);
		Carro c2 = new Carro("Corola", "NNN-9999", 656, p);
		Carro c3 = new Carro("C3", "NNN-4444", 656, p);
		//System.out.println(c);
		
		c.trocarVolante(555);
		//System.out.println(c);
		
		Detran d = new Detran("Goiânia");
		d.addCarro(c);
		d.addCarro(c2);
		System.out.println(d);
		
		d.removeCarro(c3);
		System.out.println(d);
		
		
	}
	
}
