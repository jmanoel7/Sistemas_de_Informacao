package br.com.renanrodrigues.agregacao;

public class Monitor {
	private String marca;
	
	public Monitor(String marca) {
		this.marca = marca;
	}

	public String getMarca() {
		return marca;
	}

	@Override
	public String toString() {
		return "Monitor [marca=" + marca + "]";
	}		
}








