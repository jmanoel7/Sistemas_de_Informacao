package br.com.renanrodrigues.interfaces;

public class Lampada implements Controlavel {

	private boolean estado;
	private String modelo;
	
	public Lampada (String modelo) {
		this.modelo = modelo;
	}
	
	public boolean isLigado() {		
		return estado;
	}

	public void ligar() {
		estado = true;		
	}

	public void desligar() {
		estado = false;		
	}
	
	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	@Override
	public String toString() {
		return "Lampada [estado=" + estado + ", modelo=" + modelo + "]";
	}	
}


