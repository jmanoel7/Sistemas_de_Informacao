package br.com.renanrodrigues.interfaces;

public class TesteControlavel {

	public static void main(String[] args) {
		
		TV tv = new TV("LG");		
		System.out.println(tv);
		System.out.println(tv.isLigado());
		tv.ligar();
		System.out.println(tv);
		System.out.println(tv.isLigado());
				
		Lampada lmpd1 = new Lampada("Fluorescente");
		Lampada lmpd2 = new Lampada("LED");		
		Luminaria luminaria = new Luminaria("Ferro");
		System.out.println(luminaria);
		System.out.println(luminaria.isLigado());
		
		luminaria.addLampada(lmpd1, 1);
		luminaria.addLampada(lmpd2, 2);
		System.out.println(luminaria);		
		System.out.println(luminaria.isLigado());
		
		luminaria.ligar();
		System.out.println(luminaria);	
		System.out.println(luminaria.isLigado());		
	}
}



