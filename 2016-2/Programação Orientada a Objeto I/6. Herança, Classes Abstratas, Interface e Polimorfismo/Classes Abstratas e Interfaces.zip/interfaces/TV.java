package br.com.renanrodrigues.interfaces;

public class TV implements Controlavel {
	
	private boolean estado;
	private String marca;
	
	public TV (String marca) {
		this.marca = marca;
	}
	
	public boolean isLigado() {		
		return estado;
	}

	public void ligar() {
		estado = true;		
	}

	public void desligar() {
		estado = false;		
	}
	
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "TV [estado=" + estado + ", marca=" + marca + "]";
	}	
}


