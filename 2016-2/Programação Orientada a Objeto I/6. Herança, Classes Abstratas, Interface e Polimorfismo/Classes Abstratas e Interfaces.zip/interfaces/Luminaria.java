package br.com.renanrodrigues.interfaces;

public class Luminaria implements Controlavel {
	
	private String material;

	private Lampada lmpd1;
	private Lampada lmpd2;

	public Luminaria (String material) {
		this.material = material;
	}

	public boolean addLampada(Lampada lampada, int ordem) {
		boolean sucesso = false;		
		
		if ( (ordem == 1) && (lmpd1 == null) && (lampada != lmpd2) ) {
			lmpd1 = lampada;
			sucesso = true;
		} else if ( (ordem == 2) && (lmpd2 == null) && (lampada != lmpd1) ) {
			lmpd2 = lampada;
			sucesso = true;
		}

		return sucesso;

	}

	public boolean isLigado() {		
		return ( ((lmpd1 != null) && (lmpd1.isLigado())) || ((lmpd2 != null) && (lmpd2.isLigado())) );
	}

	public void ligar() {
		
		if (lmpd1 != null) {
			lmpd1.ligar();
		}
		
		if (lmpd2 != null) {
			lmpd2.ligar();
		}
	}

	public void desligar() {
		if (lmpd1 != null) {
			lmpd1.desligar();
		}
		
		if (lmpd2 != null) {
			lmpd2.desligar();
		}		
	}

	public String getMaterial() {
		return material;
	}

	public Lampada getLampada(int ordem) {
		Lampada retorno;	

		switch (ordem) {
			case 1: retorno = lmpd1; break;
			case 2: retorno = lmpd2; break;	
			default: retorno = null;
		}

		return retorno;
	}

	@Override
	public String toString() {
		return "Luminaria [material=" + material + ", lmpd1=" + lmpd1
				+ ", lmpd2=" + lmpd2 + "]";
	}
}


