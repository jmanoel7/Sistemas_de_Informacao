package br.com.renanrodrigues.interfaces;

public interface Controlavel {

	public boolean isLigado();
	public void ligar();
	public void desligar();
	
}


