package br.com.renanrodrigues.classeAbstrata;

public class TesteFigura {

	public static void main(String[] args) {
		
		Quadrado q = new Quadrado("Verde", 5f);
		System.out.println(q.area());
		
		Circulo c = new Circulo("Azul", 3f);
		System.out.println(c.area());
		
		Figura f = new Circulo("Azul", 3f);
		
		System.out.println(f.area());
		
	}
	
}
