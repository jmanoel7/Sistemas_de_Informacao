package br.com.renanrodrigues.heranca;

public class TesteCarro {

	public static void main(String[] args) {		
		Veiculo v = new Veiculo("Gol"); 
		Veiculo c = new Carro("Palio");
		
		System.out.println(v);
		System.out.println(c);		
	}	
}







