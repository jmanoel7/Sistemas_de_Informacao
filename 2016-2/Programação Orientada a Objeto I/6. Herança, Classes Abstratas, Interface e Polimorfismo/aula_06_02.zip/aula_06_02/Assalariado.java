package aula_06_02;

public class Assalariado extends Empregado {

	private float salario;
	
	public Assalariado(String nome, float salario) {
		super(nome);
		this.salario = salario;
	}

		public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}

	@Override
	public float vencimento() {
		return salario;
	}

	@Override
	public String toString() {
		return "Assalariado [vencimento()="
				+ vencimento() + ", getNome()=" + getNome() + "]";
	}
	
}
