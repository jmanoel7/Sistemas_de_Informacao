package aula_06_02;

public class TesteFigura {

	public static void main(String[] args) {
		
		Quadrado q = new Quadrado("Azul", 4);		
		System.out.println(q);
		
		Circulo c = new Circulo("Verde", 2.5f);
		System.out.println(c);
	}
	
}
