package aula_06_02;

public class TesteControlavel {

	public static void main(String[] args) {
		
		TV tv = new TV("LG");
		System.out.println(tv);
		
		tv.ligar();
		System.out.println(tv);
		
	}
	
}
