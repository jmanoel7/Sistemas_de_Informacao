package aula_06_02;

public class Comissionado extends Empregado {

	private float totalVenda;
	
	public Comissionado(String nome, float totalVenda, float totalComissao) {
		super(nome);
		this.totalVenda = totalVenda;
		this.totalComissao = totalComissao;
	}
	private float totalComissao;
	
	
	public float getTotalVenda() {
		return totalVenda;
	}
	public void setTotalVenda(float totalVenda) {
		this.totalVenda = totalVenda;
	}
	public float getTotalComissao() {
		return totalComissao;
	}
	public void setTotalComissao(float totalComissao) {
		this.totalComissao = totalComissao;
	}
	@Override
	public float vencimento() {		
		return totalVenda + totalComissao;
	}
	@Override
	public String toString() {
		return "Comissionado [vencimento()=" + vencimento() + ", getNome()="
				+ getNome() + "]";
	}
	
	
	
}
