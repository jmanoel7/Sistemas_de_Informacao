package aula_06_02;

public class Circulo extends Figura {
	
	private float raio;
	
	public Circulo(String cor, float raio) {
		super(cor);
		this.raio = raio;
	}

	public float getRaio() {
		return raio;
	}

	public void setRaio(float raio) {
		this.raio = raio;
	}

	@Override
	public String toString() {
		return "Circulo [raio=" + raio + ", cor=" + cor + ", area()=" + area()
				+ "]";
	}

	@Override
	public float area() {
		return (float) (Math.PI * raio * raio);
	}

}
