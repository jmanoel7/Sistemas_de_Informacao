package aula_06_02;

public class TV implements Controlavel {
	
	private String marca;
	private boolean estado;	
	
	public TV(String marca) {		
		this.marca = marca;		
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	@Override
	public boolean isLigado() {
		return estado;
	}

	@Override
	public void ligar() {
		estado = true;		
	}

	@Override
	public void desligar() {
		estado = false;	
	}

	@Override
	public String toString() {
		return "TV [marca=" + marca + ", estado=" + estado + "]";
	}

}
