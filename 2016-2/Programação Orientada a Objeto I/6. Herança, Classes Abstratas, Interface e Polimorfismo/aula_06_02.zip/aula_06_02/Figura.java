package aula_06_02;

public abstract class Figura {

	protected String cor;
	
	public Figura(String cor) {		
		this.cor = cor;
	}
	
	abstract public float area();

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	@Override
	public String toString() {
		return "Figura [cor=" + cor + "]";
	}
	
}
