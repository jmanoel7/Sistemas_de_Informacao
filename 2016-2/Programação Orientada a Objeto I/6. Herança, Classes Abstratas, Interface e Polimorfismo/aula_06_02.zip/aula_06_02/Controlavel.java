package aula_06_02;

public interface Controlavel {
	
	public boolean isLigado();
	public void ligar();
	public void desligar();
	
}
