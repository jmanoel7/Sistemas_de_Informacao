package aula_06_02;

public class TesteEmpregado {

	public static void main(String[] args) {
		
		Assalariado a = new Assalariado("Renan", 500f);
		System.out.println(a);
		
		Comissionado c = new Comissionado("Maria",
				1000f, 200f);
		System.out.println(c);
		
	}
	
}
