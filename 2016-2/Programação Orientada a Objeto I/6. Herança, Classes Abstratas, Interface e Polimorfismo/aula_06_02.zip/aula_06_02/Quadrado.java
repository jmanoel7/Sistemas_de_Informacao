package aula_06_02;

public class Quadrado extends Figura {
	
	private float lado;
	
	public Quadrado(String cor, float lado) {
		super(cor);
		this.lado = lado;
	}
	
	@Override
	public float area() {
		return lado * lado;
	}

	public float getLado() {
		return lado;
	}

	public void setLado(float lado) {
		this.lado = lado;
	}

	@Override
	public String toString() {
		return "Quadrado [lado=" + lado + ", cor=" + cor + ", area()=" + area()
				+ "]";
	}

	

	

}
