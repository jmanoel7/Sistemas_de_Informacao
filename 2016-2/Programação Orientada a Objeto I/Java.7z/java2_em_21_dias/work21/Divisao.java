package work21;

public class Divisao {

    public int resultado, resto;

    public Divisao(int a, int b) {
        resultado = a / b;
        resto     = a % b;
    }

}
