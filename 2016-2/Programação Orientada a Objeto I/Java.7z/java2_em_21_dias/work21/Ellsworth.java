package work21;

public class Ellsworth {
    
    public String line1, line2, line3, line4, quote, speaker, title, from;
    
    public Ellsworth() {
	    line1 = "The advancement of the arts, from year\n";
    	line2 = "to year, taxes our credulity and seems\n";
    	line3 = "to presage the arrival of that period\n";  
    	line4 = "when human improvement must end.";
    	quote = line1 + line2 + line3 + line4;
    	speaker = "Henry Ellsworth";
    	title = "U.S. Commissioner of Patents";
    	from = "1843 Annual Report of the Patent Office";
    }

}
