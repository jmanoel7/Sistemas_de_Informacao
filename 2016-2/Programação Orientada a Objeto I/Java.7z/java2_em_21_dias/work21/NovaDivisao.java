package work21;

class NovaDivisao {

    int resultado, resto;

    NovaDivisao(int a, int b) {
        resultado = a / b;
        resto     = a % b;
    }

}
