package work21;

public class CheckString {

    public String str;

    public CheckString() {
        str = "Nobody ever went broke by buying IBM";
    }

}
