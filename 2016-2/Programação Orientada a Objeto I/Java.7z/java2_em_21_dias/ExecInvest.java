import work21.Invest;

public class ExecInvest() {

    public static void main(final String[] args) {
        Invest inv = new Invest(14000F);

        System.out.println("Lucro = " + inv.lucro + "\n");

        System.exit(0);
    }

}
