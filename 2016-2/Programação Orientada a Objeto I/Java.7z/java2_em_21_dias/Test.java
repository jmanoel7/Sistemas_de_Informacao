/**
 * Describe class Test here.
 *
 *
 * Created: Mon Aug  2 03:57:37 2010
 *
 * @author <a href="mailto:jmanoel@home">Jo�o Manoel Leite Ribeiro Nogueira</a>
 * @version 1.0
 */
public final class Test {

    /**
     * Creates a new <code>Test</code> instance.
     *
     */
    private Test() {
    }


    /**
     * Describe <code>main</code> method here.
     *
     * @param args a <code>String[]</code> value
     */
    public static void main(final String[] args) {
	System.out.println("Test!");
	System.exit(0);
    }

}
