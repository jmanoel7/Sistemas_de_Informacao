import work21.ExecNovaDivisao;

public class ExecuteDivisao1 {

    public static void main(final String[] args) {
        ExecNovaDivisao div = new ExecNovaDivisao(120,11);

        System.exit(d.exitStatus);
    }

}
