import java.awt.*;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * An image filter to detect edges and gighlight them, a bit like 
 * a colored pencil drawing.
 * 
 * @author Michael Kolling and David J Barnes 
 * @version 1.0
 */
public class EdgeFilter extends Filter
{
    private static final int tolerance = 20;
    
    private OFImage original;
    private int width;
    private int height;

    /**
     * Constructor for objects of class EdgeFilter
     */
    public EdgeFilter(String name)
    {
        super(name);
    }

    /**
     * Apply this filter to an image.
     * 
     * @param  image  The image to be changed by this filter.
     */
    public void apply(OFImage image)
    {
        original = new OFImage(image);
        width = original.getWidth();
        height = original.getHeight();
        
        for(int y = 0; y < height; y++) {
            for(int x = 0; x < width; x++) {
                image.setPixel(x, y, edge(x, y));
            }
        }
    }

    /**
     * Return a new color that is the smoothed color of a given
     * position. The "smoothed color" is the color value that is the
     * average of this pixel and all the adjacent pixels.
     */
    private Color edge(int xpos, int ypos)
    {
        ArrayList pixels = new ArrayList(9);
        
        for(int y = ypos-1; y <= ypos+1; y++) {
            for(int x = xpos-1; x <= xpos+1; x++) {
                if( x>=0 && x<width && y>=0 && y<height )
                    pixels.add(original.getPixel(x, y));
            }
        }

        return new Color(255-diffRed(pixels), 255-diffGreen(pixels), 255-diffBlue(pixels));
    }

    /**
     * Return the average of all the red values in the given list of pixels.
     */
    private int diffRed(List pixels)
    {
        int max = 0;
        int min = 255;
        for(Iterator it = pixels.iterator(); it.hasNext(); ) {
            int val = ((Color)it.next()).getRed();
            if(val > max)
                max = val;
            if(val < min)
                min = val;
        }
        int difference = max - min - tolerance;
        if(difference < 0)
            difference = 0;
        return difference;
    }

    /**
     * Return the average of all the green values in the given list of pixels.
     */
    private int diffGreen(List pixels)
    {
        int max = 0;
        int min = 255;
        for(Iterator it = pixels.iterator(); it.hasNext(); ) {
            int val = ((Color)it.next()).getGreen();
            if(val > max)
                max = val;
            if(val < min)
                min = val;
        }
        int difference = max - min - tolerance;
        if(difference < 0)
            difference = 0;
        return difference;
    }

    /**
     * Return the average of all the blue values in the given list of pixels.
     */
    private int diffBlue(List pixels)
    {
        int max = 0;
        int min = 255;
        for(Iterator it = pixels.iterator(); it.hasNext(); ) {
            int val = ((Color)it.next()).getBlue();
            if(val > max)
                max = val;
            if(val < min)
                min = val;
        }
        int difference = max - min - tolerance;
        if(difference < 0)
            difference = 0;
        return difference;
    }

}
