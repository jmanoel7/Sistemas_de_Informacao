/**
 * Model a location in a city.
 * 
 * @author David J. Barnes and Michael Kolling
 * @version 2002.06.20
 */
public class Location
{
    /**
     * Constructor for objects of class Location
     */
    public Location()
    {
    }
}
