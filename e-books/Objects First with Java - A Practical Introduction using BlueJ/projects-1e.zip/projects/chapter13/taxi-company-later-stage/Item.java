/**
 * An item in the city.
 * 
 * @author David J. Barnes and Michael Kolling
 * @version 2002.07.02
 */

public interface Item
{
    public Location getLocation();
}
