# do this to make sure

import pida.core.environment
