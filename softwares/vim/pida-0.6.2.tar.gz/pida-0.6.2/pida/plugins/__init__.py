from pida.core.environment import plugins_path as __path__
