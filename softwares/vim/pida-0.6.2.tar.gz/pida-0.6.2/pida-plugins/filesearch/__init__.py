# -*- coding: utf-8 -*- 
#XXX: needed for the glade file
from kiwi.ui.widgets.combo import ProxyComboBox

