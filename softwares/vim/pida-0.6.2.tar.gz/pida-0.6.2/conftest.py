pytest_plugins = "unittest",

import py

collect_ignore = ['tools/skeleton', 'tools/glade3-plugin', 'externals']

