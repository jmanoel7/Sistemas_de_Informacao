#! /bin/sh
a2x -f xhtml -d docs/html/ docs/txt/dev-services.txt
a2x -f xhtml -d docs/html/ docs/txt/dev-coding-style.txt
