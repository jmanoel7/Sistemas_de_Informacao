find . -name "*.glade" | xargs sed -i -e "s/.*requires.*//"
