#!/usr/bin/python
from pida.services.plugins.uploader import main
main()
