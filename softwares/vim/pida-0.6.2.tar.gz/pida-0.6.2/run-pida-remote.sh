export PYTHONPATH=`pwd`:`pwd`/externals:$PYTHONPATH 
python bin/pida-remote $@
