from unittest import TestCase

from pida.core.base import BaseConfig

class TestConfig(BaseConfig):

    """A Test Subclass"""

class BaseConfigTest(TestCase):
    pass
