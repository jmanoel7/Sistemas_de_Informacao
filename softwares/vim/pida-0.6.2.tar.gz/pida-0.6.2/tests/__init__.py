
from pida.core.log import log
log.setLevel(100)

