
def test_start(editor):
    assert editor.started
