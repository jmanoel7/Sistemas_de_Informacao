Services with need for user docs
==================================

.. note::

  this is a todo list

* Vim
* Emacs
* File Manager
* Project Manager
* Terminal/Commander
* VersionControll
* Preferences
* Plugin Manager
* Bookmark - Manage bookmark (files, directories...)
* Checklist
* GTags
* Library
* Manpage viewer
* Pastebin
* Python Plugin
* RFC Viewer
* Todo lister
* Trac connect


