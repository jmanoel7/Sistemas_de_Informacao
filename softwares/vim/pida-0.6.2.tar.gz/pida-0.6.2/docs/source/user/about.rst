About
======

PIDA is an IDE (integrated development environment).
PIDA is different from other IDEs in that it will use the tools
that are already available rather than attempting to reinvent each one.
PIDA is written in Python with the PyGTK toolkit,
and although it is designed to be used to program in any language,
PIDA has fancy Python IDE features.

CAUTION: Since PIDA is still being actively worked on, this manual is still
incomplete and will grow with time.

