

The PIDA Users' Handbook
========================

.. toctree::
   :maxdepth: 1

   introduction
   installation
   gettingstarted
