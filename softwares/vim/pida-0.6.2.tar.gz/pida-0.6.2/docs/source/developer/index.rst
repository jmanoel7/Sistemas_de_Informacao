

The PIDA Developers' Handbook
=============================

.. toctree::
   :maxdepth: 1

   introduction
   sourcecode
   service/index
   codingstyle

