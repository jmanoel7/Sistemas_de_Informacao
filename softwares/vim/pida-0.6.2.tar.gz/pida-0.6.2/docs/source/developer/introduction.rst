

Introduction
============

This handbook will aid developers in understanding, and writing code for the
PIDA IDE.

