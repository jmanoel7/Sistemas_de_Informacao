
Service Overview
================

A service is comprised of a directory on the file system. This directory is a
Python package with data.

The structure of this directory is like so for a service named "myservice"::

    myservice/
        __init__.py
        myservice.py
        service.pida
        test_myservice.py
        data/
        glade/
        pixmaps/
        uidef/
            myservice.xml

