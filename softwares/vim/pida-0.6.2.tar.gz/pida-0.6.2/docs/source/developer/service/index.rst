
Plugin Authoring Guide
======================


.. toctree::
   :maxdepth: 2

   overview
   creating
   components
   options
   commands
   events
   views
   dbus
   publishing

