.. This file stores all the links used throughout the source.
   This is done in order to prevent endless reStructured text link declarations pointlessly.

.. A
.. B

.. _Bazaar: http://bazaar-vcs.org/

.. C
.. D

.. _Downloads: http://pida.co.uk/downloads

.. E
.. F
.. G

.. _`GTK Web Site`: http://www.gtk.org/ 

.. H
.. I
.. J
.. K
.. L
.. M

.. _Mercurial: http://www.selenic.com/mercurial/

.. N
.. O
.. P

.. _`PyGTK Web Site`: http://www.pygtk.org/ 
.. _PyGTK: http://www.pygtk.org/ 
.. _`Python Web Site`: http://python.org/
.. _Python: http://www.python.org/
.. _PIDA: http://pida.co.uk/

.. Q
.. R
.. S
.. T

.. _Trac: http://pida.co.uk/

.. U
.. V
.. W

.. _`Windows Installation`: http://pida.co.uk/wiki/WindowsInstallation
.. _Wiki: http://pida.co.uk/wiki/

.. X
.. Y
.. Z
