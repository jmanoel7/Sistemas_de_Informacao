Welcome to the PIDA documentation!
==================================

.. toctree::
   :maxdepth: 1

   user/index
   developer/index

There is also a PDF_ version of this Documentation.

.. *** Change this, obviously.

.. _PDF: http://greamin.com/pida-test/PIDA.pdf

.. Indices and tables
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`
